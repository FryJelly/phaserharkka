<?php
if (!isset($_SESSION['abook_islogged']) || $_SESSION['abook_islogged'] !== true) {
   echo "[Vieras] ";
   echo "[ <a href='login.php'>Kirjaudu</a> ]";
} else {
   echo "[Kirjautunut: <span style='background: yellow;'>{$_SESSION['tunnus']}</span> ] ";
   echo "[<a href='logout.php'>Kirjaudu ulos</a>]<br><hr>\n";
} 
echo "[<a href='mainpage.php'>Palaa etusivulle</a>]";
?>

<form method='get' action='list.php'>
[ <a href='list.php'>Highscores</a> ]
Etsi:
<input type='text' size='10' name='hakuehto' value=''>
</form>
<hr>