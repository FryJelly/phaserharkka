<style type='text/css'>
tr:nth-child(odd) {background: #f1f1f1}
tr:nth-child(even) {background: #ffffff}
tr:nth-child(1) {background: #ffeedd}
</style>
<form method="post" action="list.php">
    <input name="hakuinput"><input type="submit" value="Hae">
</form>
<hr>
<?php
  
session_start();

include ("auth-user.php");
required_auth_level("none");

include ("navbar.php");

require_once ("/home/K9105/php_dbconfig/db-init.php");
  
$hakuehto = isset($_POST['hakuinput']) ? $_POST['hakuinput'] : '';
      
$stmt = top10($db, $hakuehto);
sqlResult2Html($stmt);
  
// 
function top10($db, $hakuehto) {
   $sql = <<<SQLEND
   SELECT * FROM Scores ORDER by score  DESC, ts ASC LIMIT 10
SQLEND;
  
   $stmt = $db->prepare("$sql");
   $stmt->bindValue(':hakuehto', "%$hakuehto%", PDO::PARAM_STR);
   $stmt->execute();
   return $stmt;    
}
  
// SQL-kyselyn tulosjoukko HTML-taulukkoon.
function sqlResult2Html($stmt) {
  
$row_count = $stmt->rowCount();
$col_count  = $stmt->columnCount();

echo "<table border='0'>\n";  
$output = <<<OUTPUTEND
<tr bgcolor='#ffeedd'>
<td>Rank</td><td>Name</td><td>Score</td><td>Date & Time</td>
</tr>
OUTPUTEND;
echo $output;

    $rownum = 1;
    
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $output = <<<OUTPUTEND
    <tr>
    <td>{$rownum}</td><td>{$row['name']}</td><td>{$row['score']}</td><td>{$row['ts']}</td>
   </tr>
OUTPUTEND;
    echo $output;
    $rownum++;
}
echo "</table>\n";
}
  
?>