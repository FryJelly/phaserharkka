<?php
// logout.php
session_start();

if (isset($_SESSION['abook_islogged'])) {
    unset($_SESSION);
    session_destroy();
}

header("Location: http://" . $_SERVER['HTTP_HOST']
                           . dirname($_SERVER['PHP_SELF']) . '/'
                           . "list.php"); 

?>