  
<a href='list.php'>Palaa</a>

<?php
//  abook-lisaa.php

/*include ("auth-user.php");
required_auth_level("sameuser");*/

require_once ("/home/K9105/php_dbconfig/db-init.php");
  
$name = isset($_POST['name']) ? $_POST['name'] : '';
$score = isset($_POST['score']) ? $_POST['score'] : '';
      
//$stmt = lisaaHenkilo($db, $tunnus, $sukunimi, $etunimi, $osoite, $puhnro, $email);
 
  
// 
//function lisaaHenkilo($db, $tunnus, $sukunimi, $etunimi, $osoite, $puhnro, $email) {
$sql = <<<SQLEND
INSERT INTO Scores (name,score,ts) 
VALUES(:f1,:f2,CURRENT_TIMESTAMP)
ON DUPLICATE KEY UPDATE
   ts = if('$score'>score,CURRENT_TIMESTAMP,ts), score = if ('$score'>score, '$score', score);"; 
SQLEND;

$stmt = $db->prepare("$sql");
$stmt->execute(array(':f1' => $name, ':f2' => $score));

$affected_rows = $stmt->rowCount();
echo $affected_rows . " riviä lisättiin<hr>\n";

/*
$query = "INSERT INTO Scores
SET name = '$name'
   , score = '$score'";
   //$stmt = $db->prepare($sql);
   $stmt = $db->prepare("INSERT INTO Scores (name,score) VALUES(:f1,:f2)");
$stmt->execute(array(':f1' => $name, ':f2' => $score));
$affected_rows = $stmt->rowCount();
   return $stmt;    
//}
 
$rows = $stmt->rowCount();

echo "$name lisättiin!";*/
 
?>