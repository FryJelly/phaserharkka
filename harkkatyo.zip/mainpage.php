<?php
session_start();

include ("auth-user.php");
required_auth_level("none");

include ("navbar.php");
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Main page</title>
    <style>
        html,
        body {
          margin: 0;
          padding: 0;
          background-color: lightgray;
          text-align: center;
        }
        #background{
            margin: auto;
            text-align: center;
            background-image:url(https://student.labranet.jamk.fi/~K9105/phaser/harkkatyo/Ruined_Sky/assets/waterfall.jpg);
            height: 576px;
            background-position: center;
            background-repeat: no-repeat;
            background-size:auto;
        }
        #menu {
            text-align: center;
            background-color: transparent;
        }
        #gamelink {
            font-size: 50px;
            color: black;
            
        }
    </style>
</head>

<body>
    <div id="background">
        <div id="menu">
            <span>Ruined Sky - Game</span><br>
            <a id="gamelink" href='https://student.labranet.jamk.fi/~K9105/phaser/harkkatyo/Ruined_Sky/index.html'>Start Game</a>
        </div>
        </div>

</body>
</html>