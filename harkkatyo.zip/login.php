<?php
session_start();
require_once '/home/K9105/php-password-lib/PasswordLib.phar';
$lib = new PasswordLib\PasswordLib();

require_once('/home/K9105/php_dbconfig/db-init.php');

$errmsg = '';

if (isset($_SESSION['autherrmsg']) ) {
    echo $_SESSION['autherrmsg'];
    unset ($_SESSION['autherrmsg']);
    exit();
}
$_SESSION['errmsg'] = '';

if (isset($_POST['uid']) AND isset($_POST['passwd'])) {
   $uid = $_POST['uid'];
   $passwd = $_POST['passwd'];

   $sql = "SELECT tunnus, password
            FROM henkilotpwds
            WHERE tunnus = :uid";
    
    $stmt = $db->prepare($sql);
    $stmt->execute(array($uid));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);  

    if ($stmt->rowCount() == 1 AND $lib->verifyPasswordHash($passwd, $row['password'])) {

        $_SESSION['abook_islogged'] = true;
        $_SESSION['tunnus'] = $_POST['uid'];
         header("Location: http://" . $_SERVER['HTTP_HOST']
                                    . dirname($_SERVER['PHP_SELF']) . '/'
                                    . "abook-listaa.php");
        exit;
    } else {
        $errmsg = '<span style="background: yellow;">Tunnus/Salasana vaarin!</span>';
    }
}
?>

<title>Kirjautusmislomake</title>

<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>"
style=color:#000;background-color:#eeeeee>
Tunnus:<br><input type="text" name="uid" size="30"><br>
Salasana:<br><input type="text" name="passwd" size="30"><br>
<input type='submit' name='action' value='Kirjaudu'>
<br>
</form>
