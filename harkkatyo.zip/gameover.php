<?php
session_start();

include ("auth-user.php");
required_auth_level("none");

include ("navbar.php");
$playerScore = 'playerScore';
?>

<html>
    <head>
    <meta charset="UTF-8">
    <title>Main page</title>
    <style>
        html,
        body {
          margin: 0;
          padding: 0;
          background-color: lightgray;
          text-align: center;
        }
    </style>
</head>
<body>

<?php
if(!isset($_COOKIE[$playerScore])) {
    echo "playerScore cookie not found!";
} else {
    echo "Your score is: " . $_COOKIE[$playerScore];
}
?>

</body>
</html> 