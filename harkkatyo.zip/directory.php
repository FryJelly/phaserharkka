<?php
// osoitekirja.php
 
require_once ("/home/K9105/php_dbconfig/db-init.php");
require_once("directory.php");
 
$name       = (isset($_REQUEST['name'])) ?
                $_REQUEST['name'] : '';
 
tulosta_sivun_alku();
navigointivalikko($name);
 
//Painikkeet lomakkeeseen
$painikkeet  = "<input type='submit' " .
                  "name='action' value='Tallenna' " .
                  "onclick=\"javascript: " .
                  "return confirm('Hyväksy lisäys?')\"><br>\n";
 
//Haetaan tietokannan taulun kenttien nimet
$sql = "SELECT * FROM Scores";
   $result = query($sql);
   if (!($result)) {
       echo "Tietokantakysely ei onnistunut! LOPETETAAN.";
      exit();
   }
 
$cols = mysql_num_fields($result);
    
echo "<em>Add score</em>";
echo "<form method='post' action='add.php'>\n";
echo "<table border='0' cellpadding='5'>\n";
   for($i = 0; $i < $cols; $i++) {
       
      // Kentän nimi $fn-muuttuujaan
      $fn = mysql_field_name($result, $i);
      $uc_fn = ucfirst($fn);
            
      echo "<tr valign='top'>\n";
       
      // Kentän nimi $fn taulukon vasempaan sarakkeeseen
      echo "  <td align='right' bgcolor='#ffeedd'>$uc_fn</td>\n";
         echo "  <td><input type='text' name='$fn' " .
              "size='30' value=''>";
 
      echo "</td>\n</tr>\n";
      } 
   echo "</table>\n$painikkeet</form>\n\n";