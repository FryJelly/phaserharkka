var config = {
    type: Phaser.AUTO,
    width: 1000,
    height: 600,
    parent: 'content',
    physics: {
        default: 'arcade',
        arcade: {
            gravity: {y: 800},
            debug: false
        }
    },
    scene: {
        key: 'main',
        preload: preload,
        create: create,
        update: update
    },
    audio: {
        disableWebAudio: true
    }
};

var game = new Phaser.Game(config);

var map;
var falling;
var player;
var cursors;
var groundLayer;
var spikeLayer;
var fallingLayer;
var shrubberyLayer;
var coinLayer;
var checkpointLayerOne;
var checkpointLayerTwo;
var winLayer;
var deadLayer;
var backgroundLayer;
var text;
var textLives;
var lives = 5;
var score = 0;
var totalScore;
var music;
var deathSound;
var coinGet;
var colliderActivated = true;
var checkpointFirst = false;
var checkpointSecond = false;

function preload() {
    // map made with Tiled in JSON format
    this.load.tilemapTiledJSON('map', 'assets/map.json');
    // tiles in spritesheet 
    this.load.spritesheet('tiles', 'assets/tiles.png', {frameWidth: 32, frameHeight: 32});
    this.load.spritesheet('clouds', 'assets/clouds.png', {frameWidth: 32, frameHeight: 32});
    this.load.spritesheet('coins', 'assets/kolikko.png', {frameWidth: 16, frameHeight: 16});
    //images
    this.load.image('spikes', 'assets/spikes.png');
    this.load.image('falling', 'assets/falling.png');
    this.load.image('win', 'assets/winorb.png');
    this.load.image('dead', 'assets/winorb.png');
    this.load.image('checkpoint', 'assets/checkpoint.png');
    this.load.image('checkpoint2', 'assets/checkpoint2.png');
    // loading the player spritesheet
    this.load.spritesheet('player', 'assets/mani2.png', { frameWidth: 48, frameHeight: 48 });
    //loading audio and sound effects
    this.load.audio('divisionblade', ['assets/audio/schematist-division-blade.mp3' , 'assets/audio/schematist-division-blade.ogg']);  
    this.load.audio('splat', ['assets/audio/impactsplat03.mp3' , 'assets/audio/impactsplat03.ogg']);
    this.load.audio('bling', ['assets/audio/CoinGet.wav']);
    
}

function create() {
    //luodaan musiikki ja äänieffekti
    music = this.sound.add('divisionblade', {volume: 0.4});
    deathSound = this.sound.add('splat');
    coinGet = this.sound.add('bling');
    //soitetaan sitä musiikkia
    music.play();
    music.once('looped', function(music){});
    

    // load the map 
    map = this.make.tilemap({key: 'map'});

    // Laivetaan tilesetti layerille. 'clouds' viittaa preloadissa ladatulle spritesheetille
    // annettuun avaimeen.
    var backgroundTiles = map.addTilesetImage('clouds');
    // Luodaan layer. 'Clouds', huom. Iso Alkukirjain, viittaa Tiledillä luodun mapin
    // layerin nimeen.
    backgroundLayer = map.createDynamicLayer('Clouds', backgroundTiles, 0, 0);


    var groundTiles = map.addTilesetImage('tiles');
    groundLayer = map.createDynamicLayer('Solid Blocks', groundTiles, 0, 0);
    
    // Pari tapaa säätää collisio layerin kanssa
    groundLayer.setCollisionByExclusion([-1]);
    groundLayer.setCollisionByProperty({ collides: true });

    // Käytetään yksittäistä kuvaa tilesettinä
    var coinTiles = map.addTilesetImage('coins');
    // Lisätään kolikot tileinä
    coinLayer = map.createDynamicLayer('Coins', coinTiles, 0, 0);
    
    var shrubberyTiles = map.addTilesetImage('tiles');
    shrubberyLayer = map.createDynamicLayer('Shrubbery', shrubberyTiles, 0, 0);
    
    var winTiles = map.addTilesetImage('win');
    winLayer = map.createDynamicLayer('Win', winTiles, 0, 0);
    
    var deadTiles = map.addTilesetImage('dead');
    deadLayer = map.createDynamicLayer('Dead', deadTiles, 0, 0);
    
    var spikeTiles = map.addTilesetImage('spikes');
    spikeLayer = map.createDynamicLayer('Spikes', spikeTiles, 0, 0);
    spikeLayer.setCollisionByExclusion([-1]);
    spikeLayer.setCollisionByProperty({ collides: true });
    
    var fallingTiles = map.addTilesetImage('falling');
    fallingLayer = map.createDynamicLayer('Falling', fallingTiles, 0, 0);
    fallingLayer.setCollisionByExclusion([-1]);
    fallingLayer.setCollisionByProperty({ collides: true });
    
    var checkpointTilesOne = map.addTilesetImage('checkpoint');
    checkpointLayerOne = map.createDynamicLayer('CheckpointOne', checkpointTilesOne, 0, 0);
    
    var checkpointTilesTwo = map.addTilesetImage('checkpoint2');
    checkpointLayerTwo = map.createDynamicLayer('CheckpointTwo', checkpointTilesTwo, 0, 0);

    // set the boundaries of our game world
    this.physics.world.bounds.width = groundLayer.width;
    this.physics.world.bounds.height = groundLayer.height;
    
    // Spawnpoint juttuja
    //const spawnPoint = map.findObject("Objects", obj => obj.name === "Spawn");
    //player = this.physics.add.sprite(spawnPoint.x, spawnPoint.y); //"atlas", "misa-front");
    
    // Pelaajaspriten luonti
    player = this.physics.add.sprite(150, 1580, 'player');
    player.setBounce(0); // our player will bounce from items
    player.setCollideWorldBounds(false); // don't go out of the map    
    
    // Pelaajan hitboxin/bodyn säätöä
    player.body.setSize(player.width-20, player.height);
    
    // Mihin pelaaja collideaa 
    this.physics.add.collider(groundLayer, player);
    this.physics.add.collider(fallingLayer, player);
    
    // Laitetaan collision tekemään juttuja
    this.physics.add.collider(spikeLayer, player, spikeHit, ()=>{
    return colliderActivated;
  }, this);
    
    this.physics.add.collider(deadLayer, player, fallOut, ()=>{
    return colliderActivated;
  }, this);
        
    // Kun pelaaja osuu kunkin layerin tiettyyn tileen, kutsuu peli funktioita.
    // esim. 275 on map.jsonista katsottu firstgid kolikoille.
    coinLayer.setTileIndexCallback(275, collectCoin, this);
    
    spikeLayer.setTileIndexCallback(274, spikeHit, this);
    
    winLayer.setTileIndexCallback(281, winGame, this);
   
    deadLayer.setTileIndexCallback(285, fallOut, this);
    
    checkpointLayerOne.setTileIndexCallback(289, collectCheckpointOne, this);
    
    checkpointLayerTwo.setTileIndexCallback(294, collectCheckpointTwo, this);
    
    // Säädetyt overlapit layereille, jotta pelaaja voi overlapata niiden kanssa ja
    // peli tehdä asioita, mm. kerätä niitä penteleen kolikoita.
    this.physics.add.overlap(player, coinLayer);
    //this.physics.add.overlap(player, fallingLayer);
    this.physics.add.overlap(player, winLayer);
    
    this.physics.add.overlap(player, checkpointLayerOne);
    this.physics.add.overlap(player, checkpointLayerTwo);
    
    // player walk animation
    this.anims.create({
        key: 'walk',
        frames: this.anims.generateFrameNames('player', {start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });
    // idle with only one frame, so repeat is not neaded
    this.anims.create({
        key: 'idle',
        frames: [{key: 'player', frame: 1}],
        frameRate: 10,
    });
    
    this.anims.create({
        key: 'jump',
        frames: this.anims.generateFrameNames('player', {start: 4, end: 6 }),
        frameRate: 5,
        repeat: -1
    });


    cursors = this.input.keyboard.createCursorKeys();

    // set bounds so the camera won't go outside the game world
    this.cameras.main.setBounds(0, 0, map.widthInPixels, map.heightInPixels);
    // make the camera follow the player
    this.cameras.main.startFollow(player);

    // set background color, so the sky is not black    
    this.cameras.main.setBackgroundColor('#40b3ff'); //('#ccccff');
    
    // this text will show the score
    text = this.add.text(20, 570, score, {
        fontSize: '25px',
        fill: '#000000'
    });
    
    // elämätekstit
    textLives = this.add.text(20, 20, lives, {
        fontSize: '25px',
        fill: '#000000'     
    });
        
    // fix the text to the camera
    text.setScrollFactor(0);
    textLives.setScrollFactor(0);
}

// this function will be called when the player touches a coin
function collectCoin(sprite, tile) {
    coinLayer.removeTileAt(tile.x, tile.y); // poistaa kosketetun/overlapatyn kolikon/tilen
    coinGet.play();
    score++;
    text.setText(score); // päivittää scoretekstin
    return false;
}

function collectCheckpointOne(sprite, tile) {
    checkpointLayerOne.removeTileAt(tile.x, tile.y);
    coinGet.play();
    checkpointFirst = true;
    return false;
}

function collectCheckpointTwo(sprite, tile) {
    checkpointLayerTwo.removeTileAt(tile.x, tile.y);
    coinGet.play();
    checkpointSecond = true;
    return false;
}

function spikeHit(sprite, tile) {
    playerDeath();
    return false;
}

function fallOut(sprite, tile) {
    playerDeath();
    return false;
}


function winGame(sprite, tile) {
    winLayer.removeTileAt(tile.x, tile.y);
    coinGet.play();
    music.stop();
    totalScore = lives+1 * score * 1.5;
    console.log(totalScore);
    document.cookie = "playerScore=" + totalScore + "; path=/";
    
    return totalScore;
}

function playerDeath() {
    deathSound.play();
    lives--;
    textLives.setText(lives);
    player.body.setVelocityY(-400);
    player.anims.play('jump', true);
    colliderActivated = false;
    if (lives <= 0) 
    { gameOver();
    }   else if(checkpointSecond == true) {
        this.player.body.reset(6220, 1450);
        colliderActivated = true;
    }  
        else if(checkpointFirst == true) {
        this.player.body.reset(3675, 1365);
        colliderActivated = true;
        
    }
    else 
    {
    this.player.body.reset(150, 1580);
    colliderActivated = true;
    }
    return false;
}

function gameOver() {
    game.scene.stop('main');
    music.stop();
    totalScore = lives+1 * score;
    console.log(totalScore);
    document.cookie = "playerScore=" + totalScore + "; path=/";
    setTimeout(function () {
   window.location.href= 'https://student.labranet.jamk.fi/~K9105/phaser/harkkatyo/gameover.php';
}, 1500);
    return totalScore;
}


function update(time, delta) {
    if (cursors.left.isDown)
    {
        player.body.setVelocityX(-300);
        player.anims.play('walk', true); // walk left
        player.flipX = true; // flip the sprite to the left
    }
    else if (cursors.right.isDown)
    {
        player.body.setVelocityX(300);
        player.anims.play('walk', true);
        player.flipX = false; // use the original sprite looking to the right
    } else {
        player.body.setVelocityX(0);
        player.anims.play('idle', true);
    }
    // jump 
    if (cursors.up.isDown && player.body.onFloor())
    {
        player.body.setVelocityY(-400);
        player.anims.play('jump', true);
    }
}