<?php
function required_auth_level($authlevel, $tunnus="dummy")
{
	switch ($authlevel) {
		case "admin":
     // login-sivulle, jos ei "admin-logged"
			if (!isset($_SESSION['abook_islogged']) || $_SESSION['abook_islogged'] !== true || $_SESSION['tunnus'] !== "admin") {                           
				$_SESSION['autherrmsg'] = "Tarvitaan admin-oikeuksia!";
				header("Location: http://" . $_SERVER['HTTP_HOST']
                                  . dirname($_SERVER['PHP_SELF']) . '/'
                                  . "login.php");                          
				exit();
			}       
		break;
   case "sameuser":
			// login-sivulle, jos ei "admin-logged" tai ei "sameuser-logged"
			if ($_SESSION['tunnus'] !== "admin" && (!isset($_SESSION['abook_islogged']) || $_SESSION['abook_islogged'] !== true || $_SESSION['tunnus'] !== $tunnus)) {                          
				$_SESSION['autherrmsg'] = "Vain omia tietoja voi muokata!";                         
				header("Location: http://" . $_SERVER['HTTP_HOST']
                                  . dirname($_SERVER['PHP_SELF']) . '/'
                                  . "login.php");
       exit();
			}       
		break;
   default:
	}   
} 

?>
