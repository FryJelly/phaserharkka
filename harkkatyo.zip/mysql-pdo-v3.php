<?php
// mysql-pdo-v3.php
require_once("/home/K9105/php_dbconfig/db-init.php");

$stmt = $db->query('SELECT * FROM Scores ORDER by score DESC');
echo "<table border='1'>\n";
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
  echo "<tr><td>{$row['name']}</td><td>{$row['score']}</td></tr>\n";
}
echo "</table>\n";
?>